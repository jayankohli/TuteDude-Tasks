Module 22
OpenCV module Implementations
