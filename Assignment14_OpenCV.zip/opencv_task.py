import cv2
import numpy as np

img = np.zeros((300,300,3),dtype=np.uint8)
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
cv2.imshow("image",gray)
cv2.waitKey(1000)
cv2.destroyAllWindows()
