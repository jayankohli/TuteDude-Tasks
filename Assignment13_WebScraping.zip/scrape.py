import requests
from bs4 import BeautifulSoup

url = "https://example.com"
r = requests.get(url)
soup = BeautifulSoup(r.text,"html.parser")

titles = soup.find_all("h1")
for t in titles:
    print(t.text)
