ASSIGNMENT 13
Module 21: Web Scraping module Implementation
