import tkinter as tk

root = tk.Tk()
root.title("Calculator")

entry = tk.Entry(root, width=20, borderwidth=5, font=("Arial", 18))
entry.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

def click(number):
    entry.insert(tk.END, number)

def clear():
    entry.delete(0, tk.END)

def evaluate():
    try:
        result = eval(entry.get())
        entry.delete(0, tk.END)
        entry.insert(tk.END, result)
    except:
        entry.delete(0, tk.END)
        entry.insert(tk.END, "Error")

buttons = [
    ('7',1,0),('8',1,1),('9',1,2),('/',1,3),
    ('4',2,0),('5',2,1),('6',2,2),('*',2,3),
    ('1',3,0),('2',3,1),('3',3,2),('-',3,3),
    ('0',4,0),('.',4,1),('=',4,2),('+',4,3),
]

for (text, r, c) in buttons:
    if text == '=':
        cmd = evaluate
    else:
        cmd = lambda t=text: click(t)
    tk.Button(root, text=text, padx=20, pady=20, command=cmd).grid(row=r, column=c)

tk.Button(root, text="C", padx=20, pady=20, command=clear).grid(row=5, column=0, columnspan=4, sticky="we")

root.mainloop()
