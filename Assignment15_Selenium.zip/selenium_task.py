from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://example.com")
data = driver.find_element(By.TAG_NAME,"h1").text
print(data)
time.sleep(2)
driver.quit()
